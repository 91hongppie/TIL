<template>
  <div id="app">
    <div class="container">
      <!-- <h1>HELLO</h1> -->
      <!-- <movie-list></movie-list> -->
      <movie-list :movies="movies" :genres="genres"></movie-list> 

      <!-- <div v-for="movie in movies" :key="movie.id">
        {{ movie.name }}
      </div> -->
      <!-- <modal-fade></modal-fade> -->

    </div>
  </div>
</template>

<script>
const axios = require('axios');
// const console = require('console');
// 1-1. 저장되어 있는 MovieList 컴포넌트를 불러오고,
import MovieList from './components/movies/MovieList.vue'



export default {
  name: 'app',
  // 1-2. 아래에 등록 후
  components: {
    MovieList
  },
  data() {
    return {
      // 활용할 데이터를 정의하시오.
      movies: [
        // {id: ''},
        // {name: ''},
        // {rating: ''},
        // {genre_id: ''},
        // {director: ''},
        // {user_rating: ''},
        // {poster_url: ''},
        // {description: ''},
      ],

      genres : [
        // {id: ''},
        // {name: ''},
      ],
    }
  },
  mounted() {
    const GENRE_URL = 'https://gist.githubusercontent.com/edujunho-hphk/b7d063a9efd11acba51f6dcedcc8c520/raw/d2cae437669b41c7316c426f5451ef34792b9f39/genre.json'
    const MOVIE_URL = 'https://gist.githubusercontent.com/edujunho-hphk/1a75dbae2f69a33d1519a8703d5afa5c/raw/05bc2a01ad9ad0338bf67a15be321a1e1858ab4f/movies.json'
    axios.get(MOVIE_URL)
      .then(response => 
        // console.log(response)
        this.movies = response.data
    // 0. mounted 되었을 때, 
    // 1) 제시된 URL로 요청을 통해 data의 movies 배열에 해당 하는 데이터를 넣으시오. 
    // 2) 제시된 URL로 요청을 통해 data의 genres 배열에 해당 하는 데이터를 넣으시오.
    // axios는 위에 호출되어 있으며, node 설치도 완료되어 있습니다.
      ),
    axios.get(GENRE_URL)
      .then(response =>
        // console.log(response)
        this.genres = response.data
      )
      // this.$emit
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}

</style>
